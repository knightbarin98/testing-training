package com.linkedinlearning.reverser;

import org.apache.commons.lang3.StringUtils;

public class StringReverser {
    public String reverse(String in) {
        return StringUtils.reverse(in);
    }
}